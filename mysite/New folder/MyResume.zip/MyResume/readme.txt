Thanks for downloading this theme!

Theme Name: MyResume
Theme URL: https://bootstrapmade.com/free-html-bootstrap-template-my-resume/
Author: BootstrapMade
Author URL: https://bootstrapmade.com